import { createApp } from 'vue'
import './style.css'
import './RatioKit.scss'
import App from './App.vue'

createApp(App).mount('#app')

