import { createApp } from 'vue';
import StarterApp from './StarterApp.vue';
import '../../RatioKit.scss';

createApp(StarterApp).mount('#app');
